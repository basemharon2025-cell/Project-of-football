public class Rectangle {

    private double length;
    private double width;

    public void setLength(double L)
    {
        length=L;
    }
    public void setWidth(double W)
    {
        width=W;
    }

    public double getLength()
    {
        return length;
    }
    public double getWidth()
    {
        return width;
    }
    public double getarea()
    {
        return length*width;
    }

}
