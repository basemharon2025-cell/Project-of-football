public class premierPlayers {

    private String name;
    private int goals;
    private String time;

    public void setPlayer(String n, int g, String t) {
        name = n;
        goals = g;
        time = t;
    }

    public String getPlayer() {
        return "Player : " + name + " ==> Goals: " + goals + "  ==> Time played: " + time;
    }
}
