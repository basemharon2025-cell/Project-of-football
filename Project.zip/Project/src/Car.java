public class Car {
    private String maker;
    private int modelYear;

    public Car()
    {
        maker = "Kia";
        modelYear=2010;
    }

    public Car(String m,int mod)
    {
        maker=m;
        modelYear=mod;
    }

    public void setmaker(String m) {
        if (m.equals("toyota") || m.equals("mazda") || m.equals("mercedes")) {
            maker = m;
        } else {
            System.out.println("Invalid maker");
        }
    }

    public void setmodelyear(int model) {
        if (model > 0) {
            modelYear = model;
        } else {
            System.out.println("Invalid year");
        }
    }

    public String getmaker() {
        return maker;
    }

    public int getmodelyear() {
        return modelYear;
    }

}





